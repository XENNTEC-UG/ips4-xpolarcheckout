//<?php

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	exit;
}

class xpolarcheckout_hook_code_memberProfileTab extends _HOOK_CLASS_
{
	/**
	 * Get left-column blocks — append Polar payment summary block
	 *
	 * @return	array
	 */
	public function leftColumnBlocks(): array
	{
		try
		{
			try
			{
				$return = parent::leftColumnBlocks();
				$return[] = 'IPS\xpolarcheckout\extensions\core\MemberACPProfileBlocks\PolarPaymentSummary';
				return $return;
			}
			catch ( \Throwable $e )
			{
				return parent::leftColumnBlocks();
			}
		}
		catch ( \Error | \RuntimeException $e )
		{
			if( \defined( '\IPS\DEBUG_HOOKS' ) AND \IPS\DEBUG_HOOKS )
			{
				\IPS\Log::log( $e, 'hook_exception' );
			}

			if ( method_exists( get_parent_class(), __FUNCTION__ ) )
			{
				return \call_user_func_array( 'parent::' . __FUNCTION__, \func_get_args() );
			}
			else
			{
				throw $e;
			}
		}
	}
}
