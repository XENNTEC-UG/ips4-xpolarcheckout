<?php
/**
 * @brief		X Polar Checkout Gateway Application Class
 * @author		<a href='https://xenntec.com/'>XENNTEC UG</a>
 * @copyright	(c) 2023 XENNTEC UG
 * @package		Invision Community
 * @subpackage	X Polar Checkout Gateway
 * @since		16 Jan 2023
 * @version		
 */
 
namespace IPS\xpolarcheckout;

/**
 * X Polar Checkout Gateway Application Class
 */
class _Application extends \IPS\Application
{
	
}
