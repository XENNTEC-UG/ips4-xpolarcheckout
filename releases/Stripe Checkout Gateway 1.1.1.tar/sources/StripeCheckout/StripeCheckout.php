<?php
/**
 * @brief		Stripe Checkout Gateway
 * @author      https://invisiondevs.com
 */

namespace IPS\stripecheckout;

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( isset( $_SERVER['SERVER_PROTOCOL'] ) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

/**
 * Stripe Checkout Gateway
 */
class _StripeCheckout extends \IPS\nexus\Gateway
{
	/* !Features (Each gateway will override) */
	const SUPPORTS_REFUNDS = TRUE;
	const SUPPORTS_PARTIAL_REFUNDS = TRUE;
	const STRIPE_VERSION = '2024-06-20';
    
    /* !Payment Gateway */
	
	/**
	 * Authorize
	 *
	 * @param	\IPS\nexus\Transaction					$transaction	Transaction
	 * @param	array|\IPS\nexus\Customer\CreditCard	$values			Values from form OR a stored card object if this gateway supports them
	 * @param	\IPS\nexus\Fraud\MaxMind\Request|NULL	$maxMind		*If* MaxMind is enabled, the request object will be passed here so gateway can additional data before request is made	
	 * @return	\IPS\DateTime|NULL		Auth is valid until or NULL to indicate auth is good forever
	 * @throws	\LogicException			Message will be displayed to user
	 */
	public function auth( \IPS\nexus\Transaction $transaction, $values, \IPS\nexus\Fraud\MaxMind\Request $maxMind = NULL, $recurrings = array(), $source = NULL )
	{
		try {

			$settings = json_decode( $this->settings, TRUE );
			$transaction->save();

			$customer = \IPS\nexus\Customer::loggedIn();

			//
			// Creating session
			//
			$sessionBody = array(
				'mode' => 'payment',
				'success_url' => (string) $transaction->url()->setQueryString( 'pending', 1 ),
				'cancel_url' => (string) $transaction->invoice->checkoutUrl()->setQueryString( array( '_step' => 'checkout_pay', 'err' => $transaction->member->language()->get('gateway_err')  ) ),
				'currency' => $transaction->amount->currency,
				'client_reference_id' => $customer->member_id,
				'payment_intent_data' => array( 'description' => $transaction->invoice->title ),
				'metadata'             => array(
		               "transaction"       => $transaction->id,
		               "invoice"           => $transaction->invoice->id,
		               "customer"          => $transaction->member->member_id,
		               "customerEmail"     => $transaction->invoice->member->member_id ? $transaction->invoice->member->email : $transaction->invoice->guest_data[ 'member' ][ 'email' ],
		               "gateway"          => $this->id,
		           )
			);

			// Payment method
			if( $settings['method'] != 'all' )
			{
				$sessionBody['payment_method_types'] = array( $settings['method'] );
			}

			// Collect shipping address for afterpay_clearpay and affirm
			if( $settings['method'] == 'affirm' )
			{
				$sessionBody['shipping_address_collection'] = array( 'allowed_countries' => ['CA', 'US'] );
			}
			if( $settings['method'] == 'afterpay_clearpay' )
			{
				$sessionBody['shipping_address_collection'] = array( 'allowed_countries' => ['AU', 'CA', 'GB', 'NZ', 'US'] );
			}

			// Billing collection
			if( $settings['address_collection'] )
			{
				$sessionBody['billing_address_collection'] = 'required';
			}

			// Tax
			if( $settings['tax_enable'] )
			{
				$sessionBody['automatic_tax'] = array( 'enabled' => 'true' );
				$sessionBody['customer_update'] = array( 'address' => 'auto' );
			}

			$sessionBody['invoice_creation'] = array( 'enabled' => 'true' );

			// Add invoice
			$sessionBody['line_items'][0] = array(
				'price_data' => array(
					'currency' => $transaction->invoice->amountToPay()->currency,
					'product_data' => array(
						'name' => \IPS\Member::loggedIn()->language()->addToStack( 'stripecheckout_payment_invoice', false, array( 'sprintf' => array( $transaction->invoice->id ) ) )
					),
					'unit_amount' => $transaction->invoice->amountToPay()->amountAsString() * 100,
				),
				'quantity' => 1
			);

			\IPS\Member::loggedIn()->language()->parseOutputForDisplay( $sessionBody['line_items'][0]['price_data']['product_data']['name'] );

			// Enable tax
			if( $settings['tax_enable'] AND $settings['tax_behavior'] )
			{
				$sessionBody['line_items'][ 0 ]['price_data']['tax_behavior'] = $settings['tax_behavior'];
			}

			$sessionBody['customer'] = $this->getCustomer( $transaction, $settings );

			$session = \IPS\Http\Url::external( 'https://api.stripe.com/v1/checkout/sessions' )
				->request( 20 )
				->setHeaders( array( 'Authorization' => "Bearer " . $settings['secret'], 'Stripe-Version' => self::STRIPE_VERSION ) )
				->post( $sessionBody )
				->decodeJson();

			if ( isset( $session['url'] ) )
			{
				?>
	            <script type='text/javascript'>
	                $( document ).ready( function() {
	                    var stripe = Stripe( '<?php echo $settings[ 'publishable' ]; ?>' );
	                    stripe.redirectToCheckout( { sessionId : '<?php echo $session['id']; ?>' } );
	                } );
	            </script>
	            <?php
	            exit;
			}
			throw new \DomainException( $session['error']['message'] );
			
		} catch ( \Exception $e ) {
			
			throw new \DomainException( $e->getMessage() );
		}	
	}

	/**
	 * Check the gateway can process this...
	 *
	 * @param	$amount			\IPS\nexus\Money		The amount
	 * @param	$billingAddress	\IPS\GeoLocation|NULL	The billing address, which may be NULL if one if not provided
	 * @param	$customer		\IPS\nexus\Customer		The customer (Default NULL value is for backwards compatibility - it should always be provided.)
	 * @param	array			$recurrings				Details about recurring costs
	 * @return	bool
	 */
	public function checkValidity( \IPS\nexus\Money $amount, \IPS\GeoLocation $billingAddress = NULL, \IPS\nexus\Customer $customer = NULL, $recurrings = array() )
	{
		$settings = json_decode( $this->settings, TRUE );

		return parent::checkValidity( $amount, $billingAddress, $customer, $recurrings );
	}

	/**
	 * Settings
	 *
	 * @param	\IPS\Helpers\Form	$form	The form
	 * @return	void
	 */
	public function getCustomer( $transaction, $settings )
	{
		$customer = \IPS\nexus\Customer::loggedIn();

		// Get client or creating new
		try {

			$profiles = $transaction->member->cm_profiles;
			if( !isset( $profiles[ $this->id ] ) )
			{
				throw new \Exception("Error Processing Request", 1);
			}

			// check if customer exists
			$client = \IPS\Http\Url::external( 'https://api.stripe.com/v1/customers/' . $profiles[ $this->id ] )
				->request( 20 )
				->setHeaders( array( 'Authorization' => "Bearer " . $settings['secret'], 'Stripe-Version' => self::STRIPE_VERSION ) )
				->get()
				->decodeJson();

			if( isset( $client['deleted'] ) AND $client['deleted'] == 1 )
			{
				throw new \Exception("Error Processing Request", 1);
			}

			$customerId = $profiles[ $this->id ];
			
		} catch ( \Exception $e ) {

			// creating one
		    $clientObject = array(
				'name' => $customer->cm_first_name . ' ' . $customer->cm_last_name,
				'email' => $customer->email
			);

		    // Add address, if need for calculating
			if( $settings['tax_enable'] )
			{
				try {
				
					$address = \IPS\Db::i()->select( '*', 'nexus_customer_addresses', array( '`member`=?', \IPS\Member::loggedIn()->member_id ) )->first();
			
					$address = json_decode( $address['address'] );
				    $addressArray = array(
				        'city'          => $address->city,
				        'country'       => $address->country,
				        'line1'         => isset( $address->addressLines[0] ) ? $address->addressLines[0] : NULL,
				        'line2'         => isset( $address->addressLines[1] ) ? $address->addressLines[1] : NULL,
				        'postal_code'   => $address->postalCode,
				        'state'         => $address->region,
				    );

				    // Add to client
				    $clientObject[ 'address' ] = $addressArray;

				} catch ( \Exception $e ) {}
			}

		    $client = \IPS\Http\Url::external( 'https://api.stripe.com/v1/customers' )
				->request( 20 )
				->setHeaders( array( 'Authorization' => "Bearer " . $settings['secret'], 'Stripe-Version' => self::STRIPE_VERSION ) )
				->post( $clientObject )
				->decodeJson();

			$customerId = $client['id'];

			// Save customer
			$profiles[ $this->id ] = $client['id'];
			$transaction->member->cm_profiles = $profiles;
	        $transaction->member->save();
		}

		return $customerId;
	}
    
    /* !ACP Configuration */
	
	/**
	 * Settings
	 *
	 * @param	\IPS\Helpers\Form	$form	The form
	 * @return	void
	 */
	public function settings( &$form )
	{
		$settings = json_decode( $this->settings, TRUE );

		$form->addHeader('stripecheckout_credits');
		$form->add( new \IPS\Helpers\Form\Text( 'stripecheckout_publishable', $settings ? $settings['publishable'] : NULL, TRUE ) );
		$form->add( new \IPS\Helpers\Form\Text( 'stripecheckout_secret', $settings ? $settings['secret'] : NULL, TRUE ) );

		$form->addHeader('stripecheckout_webhook');
		$form->add( new \IPS\Helpers\Form\Text( 'stripecheckout_webhook_url', isset( $settings['webhook_url'] ) ? $settings['webhook_url'] : NULL, FALSE, array( 'disabled' => isset( $settings['webhook_url'] ) ? FALSE : TRUE ) ) );
		$form->add( new \IPS\Helpers\Form\Text( 'stripecheckout_webhook_secret', isset( $settings['webhook_secret'] ) ? $settings['webhook_secret'] : NULL, FALSE, array( 'disabled' => isset( $settings['webhook_secret'] ) ? FALSE : TRUE ) ) );

		$form->addHeader('stripecheckout_tax');
		$form->add( new \IPS\Helpers\Form\YesNo( 'stripecheckout_tax_enable', isset( $settings['tax_enable'] ) ? $settings['tax_enable'] : FALSE, FALSE, array('togglesOn' => array('tax_behavior') ) ) );
		$form->add( new \IPS\Helpers\Form\Select( 'stripecheckout_tax_behavior', isset( $settings['tax_behavior'] ) ? $settings['tax_behavior'] : FALSE, FALSE, array( 'options' => array('inclusive' => \IPS\Member::loggedIn()->language()->get('stripecheckout_tax_behavior_inclusive'), 'exclusive' => \IPS\Member::loggedIn()->language()->get('stripecheckout_tax_behavior_exclusive') ) ), NULL, NULL, NULL, 'tax_behavior' ) );

		$form->addHeader('stripecheckout_methods');
		$form->add( new \IPS\Helpers\Form\Select( 'stripecheckout_method', isset( $settings['method'] ) ? $settings['method'] : 'all', FALSE, array(
			'options'	=> array(
				'all'				=> 'stripecheckout_methods_all',
				'card' 				=> 'stripecheckout_methods_card',
				'acss_debit' 		=> 'stripecheckout_methods_acss_debit',
				'affirm'			=> 'stripecheckout_methods_affirm',
				'afterpay_clearpay'	=> 'stripecheckout_methods_afterpay_clearpay',
				'alipay'			=> 'stripecheckout_methods_alipay',
				'au_becs_debit'		=> 'stripecheckout_methods_au_becs_debit',
				'bacs_debit'		=> 'stripecheckout_methods_bacs_debit',
				'bancontact'		=> 'stripecheckout_methods_bancontact',
				'blik'				=> 'stripecheckout_methods_blik',
				'boleto'			=> 'stripecheckout_methods_boleto',
				'cashapp'			=> 'stripecheckout_methods_cashapp',
				'customer_balance'	=> 'stripecheckout_methods_customer_balance',
				'eps'				=> 'stripecheckout_methods_eps',
				'fpx'				=> 'stripecheckout_methods_fpx',
				'giropay'			=> 'stripecheckout_methods_giropay',
				'grabpay'			=> 'stripecheckout_methods_grabpay',
				'ideal'				=> 'stripecheckout_methods_ideal',
				'klarna'			=> 'stripecheckout_methods_klarna',
				'konbini'			=> 'stripecheckout_methods_konbini',
				'link'				=> 'stripecheckout_methods_link',
				'oxxo'				=> 'stripecheckout_methods_oxxo',
				'p24'				=> 'stripecheckout_methods_p24',
				'paynow'			=> 'stripecheckout_methods_paynow',
				'pix'				=> 'stripecheckout_methods_pix',
				'promptpay'			=> 'stripecheckout_methods_promptpay',
				'sepa_debit'		=> 'stripecheckout_methods_sepa_debit',
				'sofort'			=> 'stripecheckout_methods_sofort',
				'us_bank_account'	=> 'stripecheckout_methods_us_bank_account',
				'wechat_pay'		=> 'stripecheckout_methods_wechat_pay',
			)
		) ) );

		$form->addHeader('stripecheckout_refund_settings');
		$form->add( new \IPS\Helpers\Form\YesNo( 'stripecheckout_refund_ban', isset( $settings['refund_ban'] ) ? $settings['refund_ban'] : FALSE, FALSE, array() ) );

		$form->addHeader('stripecheckout_countries');
		$form->add( new \IPS\Helpers\Form\YesNo( 'stripecheckout_address_collection', isset( $settings['address_collection'] ) ? $settings['address_collection'] : FALSE, FALSE, array() ) );
	}
	
	/**
	 * Test Settings
	 *
	 * @return	void
	 * @throws	\InvalidArgumentException
	 */
	public function testSettings( $settings )
	{
		if( !$settings['webhook_url'] AND !$settings['webhook_secret'] )
		{
			$url = (string) \IPS\Http\Url::internal( 'app=stripecheckout&module=webhook&controller=webhook', 'front' );

			$events = array(
				'charge.dispute.closed',
				'charge.dispute.created',
				'charge.refunded',
				'checkout.session.completed'
			);

			$webhook = \IPS\Http\Url::external( 'https://api.stripe.com/v1/webhook_endpoints' )
				->request( 20 )
				->setHeaders( array( 'Authorization' => "Bearer " . $settings['secret'], 'Stripe-Version' => self::STRIPE_VERSION ) )
				->post( array( 'url' => $url, 'enabled_events' => $events ) )
				->decodeJson();

			$settings['webhook_url'] = $webhook['url'];
			$settings['webhook_secret'] = $webhook['secret'];
		}

		return $settings;
	}

	/**
	 * Refund
	 *
	 * @param	\IPS\nexus\Transaction	$transaction	Transaction to be refunded
	 * @param	float|NULL				$amount			Amount to refund (NULL for full amount - always in same currency as transaction)
	 * @return	mixed									Gateway reference ID for refund, if applicable
	 * @throws	\Exception
 	 */
	public function refund( \IPS\nexus\Transaction $transaction, $amount = NULL, $reason = NULL )
	{
		$settings = json_decode( $this->settings, TRUE );

		try {
		
			$body = NULL;

			if ( $amount )
			{
				$body['amount'] = (string) $amount->multiply( new \IPS\Math\Number( '100' ) );
			}

			// Add intent
			$body['payment_intent'] = $transaction->gw_id;

			// Reason
			if( $reason )
			{
				$body['reason'] = $reason;
			}

			$refund = \IPS\Http\Url::external( 'https://api.stripe.com/v1/refunds' )
				->request( 20 )
				->setHeaders( array( 'Authorization' => "Bearer " . $settings['secret'], 'Stripe-Version' => self::STRIPE_VERSION ) )
				->post( $body )
				->decodeJson();

		} catch ( \Exception $e ) {

			\IPS\Log::log( $e );
			throw new \RuntimeException();
			
		}
	}

	/**
	 * Refund Reasons that the gateway understands, if the gateway supports this
	 *
	 * @return	array
 	 */
	public static function refundReasons()
	{
		return array(
			'duplicate' => 'stripecheckout_reason_duplicate',
			'fraudulent' => 'stripecheckout_reason_fraudulent',
			'requested_by_customer' => 'stripecheckout_reason_requested_by_customer'
		);
	}

	/**
	 * URL to view transaction in gateway
	 *
	 * @param	\IPS\nexus\Transaction	$transaction	Transaction
	 * @return	\IPS\Http\Url|NULL
 	 */
	public function gatewayUrl( \IPS\nexus\Transaction $transaction )
	{
		return \IPS\Http\Url::external( "https://dashboard.stripe.com/payments/{$transaction->gw_id}" );
	}
}