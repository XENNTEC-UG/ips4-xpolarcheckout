<?php


namespace IPS\stripecheckout\modules\front\webhook;

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( isset( $_SERVER['SERVER_PROTOCOL'] ) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

/**
 * webhook
 */
class _webhook extends \IPS\Dispatcher\Controller
{
	/**
	 * Execute
	 *
	 * @return	void
	 */
	public function execute()
	{
		parent::execute();
	}

	/**
	 * ...
	 *
	 * @return	void
	 */
	protected function manage()
	{
		$body = @file_get_contents('php://input');
		$decodedBody = json_decode( $body, TRUE );

		// 
		// charge.dispute.created event
		//
		if( $decodedBody['type'] == 'charge.refunded' )
		{
			foreach ( \IPS\nexus\Gateway::roots() as $method )
			{
				if ( $method instanceof \IPS\stripecheckout\StripeCheckout )
				{
					$gateway = $method;
				}
			}

			$settings = json_decode( $gateway->settings, TRUE );

			// Check signature
			$signature = $_SERVER['HTTP_STRIPE_SIGNATURE'];
			$this->checkSignature( $signature, $body, $settings['webhook_secret'] );

			// Get transaction
			$trId = \IPS\Db::i()->select( 't_id', 'nexus_transactions', array( 't_gw_id=?', $decodedBody['data']['object']['payment_intent'] ) )->first();

			$transaction = \IPS\nexus\Transaction::load( $trId );

			if( $settings['refund_ban'] )
			{
				$transaction->member->temp_ban = -1;
				$transaction->member->save();
			}

			$transaction->status = \IPS\nexus\Transaction::STATUS_REFUNDED;
			$transaction->save();

			\IPS\Output::i()->sendOutput( 'SUCCESS', 200 );	
		} 

		// 
		// charge.dispute.created event
		// 
		if( $decodedBody['type'] == 'charge.dispute.closed' )
		{
			try {

				foreach ( \IPS\nexus\Gateway::roots() as $method )
				{
					if ( $method instanceof \IPS\stripecheckout\StripeCheckout )
					{
						$gateway = $method;
					}
				}

				$settings = json_decode( $gateway->settings, TRUE );

				// Check signature
				$signature = $_SERVER['HTTP_STRIPE_SIGNATURE'];
				$this->checkSignature( $signature, $body, $settings['webhook_secret'] );

				// Get transaction
				$trId = \IPS\Db::i()->select( 't_id', 'nexus_transactions', array( 't_gw_id=?', $decodedBody['data']['object']['payment_intent'] ) )->first();

				$transaction = \IPS\nexus\Transaction::load( $trId );
			
				if( $decodedBody['data']['object']['status'] == 'lost' )
				{
					$transaction->status = \IPS\nexus\Transaction::STATUS_REFUNDED;
					$transaction->save();
				}
				elseif( $decodedBody['data']['object']['status'] == 'won' )
				{
					$transaction->status = $transaction::STATUS_PAID;
					$transaction->save();
					if ( !$transaction->invoice->amountToPay()->amount->isGreaterThanZero() )
					{	
						$transaction->invoice->markPaid();
					}
				}

				\IPS\Output::i()->sendOutput( 'SUCCESS', 200 );	
			
			} catch ( \Exception $e ) {
				
				\IPS\Log::log( $e );
				throw new \Exception( 'UNABLE_TO_PROCESS_DISPUT' );
			}
		}

		// 
		// charge.dispute.created event
		// 
		if( $decodedBody['type'] == 'charge.dispute.created' )
		{
			try {
			
				foreach ( \IPS\nexus\Gateway::roots() as $method )
				{
					if ( $method instanceof \IPS\stripecheckout\StripeCheckout )
					{
						$gateway = $method;
					}
				}

				$settings = json_decode( $gateway->settings, TRUE );

				// Check signature
				$signature = $_SERVER['HTTP_STRIPE_SIGNATURE'];
				$this->checkSignature( $signature, $body, $settings['webhook_secret'] );

				// Get transaction
				$trId = \IPS\Db::i()->select( 't_id', 'nexus_transactions', array( 't_gw_id=?', $decodedBody['data']['object']['payment_intent'] ) )->first();

				$transaction = \IPS\nexus\Transaction::load( $trId );

				// Ok
				$transaction->status = \IPS\nexus\Transaction::STATUS_DISPUTED;
				$extra = $transaction->extra;
				$extra['history'][] = array( 's' => \IPS\nexus\Transaction::STATUS_DISPUTED, 'on' => $decodedBody['data']['object']['created'], 'ref' => $decodedBody['data']['object']['id'] );
				$transaction->extra = $extra;
				$transaction->save();
				
				if ( $transaction->member )
				{
					$transaction->member->log( 'transaction', array(
						'type'		=> 'status',
						'status'	=> \IPS\nexus\Transaction::STATUS_DISPUTED,
						'id'		=> $transaction->id
					) );
				}
				
				/* Mark the invoice as not paid (revoking benefits) */
				$transaction->invoice->markUnpaid( \IPS\nexus\Invoice::STATUS_CANCELED );
				
				/* Send admin notification */
				\IPS\core\AdminNotification::send( 'nexus', 'Transaction', \IPS\nexus\Transaction::STATUS_DISPUTED, TRUE, $transaction );
				
				\IPS\Output::i()->sendOutput( 'SUCCESS', 200 );	

			} catch ( \Exception $e ) {
				
				\IPS\Log::log( $e );
				throw new \Exception( 'UNABLE_TO_PROCESS_DISPUT' );
			}
		}

		// 
		// checkout.session.completed event
		//
		if( $decodedBody['type'] == 'checkout.session.completed' )
		{
			try
			{
				$transaction = \IPS\nexus\Transaction::load( $decodedBody['data']['object']['metadata']['transaction'] );
			}
			catch ( \OutOfRangeException $e )
			{
				// throw new \Exception( 'UNABLE_TO_LOAD_TRANSACTION' );
				\IPS\Output::i()->sendOutput( 'SUCCESS', 200 );	return;
			}

			// Check status
			if ( $transaction->status === \IPS\nexus\Transaction::STATUS_PAID )
			{
				// throw new \Exception( 'ALREADY_GOT_IT' ); 
				\IPS\Output::i()->sendOutput( 'SUCCESS', 200 );	return;
			}

			if( $transaction->status !== \IPS\nexus\Transaction::STATUS_GATEWAY_PENDING AND $transaction->status !== \IPS\nexus\Transaction::STATUS_PENDING )
			{
				// throw new \Exception( 'BAD_STATUS' );
				\IPS\Output::i()->sendOutput( 'SUCCESS', 200 );	return;
			}

			$settings = json_decode( $transaction->method->settings, TRUE );

			// Check signature
			$signature = $_SERVER['HTTP_STRIPE_SIGNATURE'];
			$this->checkSignature( $signature, $body, $settings['webhook_secret'] );

			// Now we must to check PaymentIntent status
			$intent = \IPS\Http\Url::external( 'https://api.stripe.com/v1/payment_intents/' . $decodedBody['data']['object']['payment_intent'] )
				->request( 20 )
				->setHeaders( array( 'Authorization' => "Bearer " . $settings['secret'], 'Stripe-Version' => '2022-11-15' ) )
				->get()
				->decodeJson();

			if( $intent['status'] == "succeeded" )
			{
				$transaction->gw_id = $decodedBody['data']['object']['payment_intent'];
				$transaction->save();
				$maxMind = NULL;
				if ( \IPS\Settings::i()->maxmind_key )
				{
					$maxMind = new \IPS\nexus\Fraud\MaxMind\Request;
					$maxMind->setTransaction( $transaction );
				}

				$transaction->checkFraudRulesAndCapture( $maxMind );
			}
			elseif( $intent['status'] == "processing" )
			{
				$transaction->status = \IPS\nexus\Transaction::STATUS_GATEWAY_PENDING;
				$extra = $transaction->extra;
				$extra['history'][] = array( 's' => \IPS\nexus\Transaction::STATUS_GATEWAY_PENDING );
				$transaction->extra = $extra;
				$transaction->save();

				/* Send Notification */
				$transaction->sendNotification();
				\IPS\core\AdminNotification::send( 'nexus', 'Transaction', \IPS\nexus\Transaction::STATUS_WAITING, TRUE, $transaction );
			}
			else
			{
				throw new \Exception( 'UNRECOGNIZED_INTENT_STATUS: ' . $intent['status'] );
			}

			\IPS\Output::i()->sendOutput( 'SUCCESS', 200 );	
		}

		// 
		// checkout.session.async_payment_succeeded event | For async gateways
		//
		if( $decodedBody['type'] == 'checkout.session.async_payment_succeeded' OR $decodedBody['type'] == 'checkout.session.async_payment_failed' )
		{
			\IPS\Log::log( $decodedBody['type'] );
			try
			{
				$transaction = \IPS\nexus\Transaction::load( $decodedBody['data']['object']['metadata']['transaction'] );
			}
			catch ( \OutOfRangeException $e )
			{
				throw new \Exception( 'UNABLE_TO_LOAD_TRANSACTION' );
			}
			\IPS\Log::log( $decodedBody['data']['object']['metadata']['transaction'] );
			if( $transaction->status !== \IPS\nexus\Transaction::STATUS_GATEWAY_PENDING AND $transaction->status !== \IPS\nexus\Transaction::STATUS_PENDING )
			{
				throw new \Exception( 'BAD_STATUS' );
			}
\IPS\Log::log( $transaction->status );
			$settings = json_decode( $transaction->method->settings, TRUE );

			// Check signature
			$signature = $_SERVER['HTTP_STRIPE_SIGNATURE'];
			$this->checkSignature( $signature, $body, $settings['webhook_secret'] );
\IPS\Log::log( 'Signature checked' );
			if( $decodedBody['data']['object']['payment_status'] == "paid" )
			{
				$transaction->gw_id = $decodedBody['data']['object']['payment_intent'];
				\IPS\Log::log( 'done' );
				$transaction->save();
				$maxMind = NULL;
				if ( \IPS\Settings::i()->maxmind_key )
				{
					$maxMind = new \IPS\nexus\Fraud\MaxMind\Request;
					$maxMind->setTransaction( $transaction );
				}

				$transaction->checkFraudRulesAndCapture( $maxMind );
			}
			if( $decodedBody['data']['object']['payment_status'] == "unpaid" )
			{
				$note = 'async_payment_failed';
				$transaction->gw_id = $decodedBody['data']['object']['payment_intent'];
				$transaction->status = $transaction::STATUS_REFUSED;
				$extra = $transaction->extra;
				$extra['history'][] = array( 's' => \IPS\nexus\Transaction::STATUS_REFUSED, 'noteRaw' => $note );
				$transaction->extra = $extra;
				$transaction->save();
			}
			else
			{
				throw new \Exception( 'BAD_STATUS_FOR_async_payment_succeeded/failed' );
			}

			\IPS\Output::i()->sendOutput( 'SUCCESS', 200 );	
		}
	}
	
	protected function checkSignature( $signature, $body, $secret )
	{
		$timestamp = \explode( ',', $signature )[0];
		$timestamp = \explode( '=', $timestamp )[1];

		$signature = \explode( ',', $signature )[1];
		$signature = \explode( '=', $signature )[1];

		$signed = \hash_hmac( 'sha256', "{$timestamp}.{$body}", $secret );

		if( $signature !== $signed )
		{
			\IPS\Output::i()->sendOutput( 'SUCCESS', 200 );	
			return;
		}

		return;
	} 
}