<?php
/**
 * @brief		Stripe Checkout Gateway Application Class
 * @author		<a href='https://invisioncommunity.com/profile/533135-kirill-gromov/'>Kirill Gromov</a>
 * @copyright	(c) 2023 Kirill Gromov
 * @package		Invision Community
 * @subpackage	Stripe Checkout Gateway
 * @since		16 Jan 2023
 * @version		
 */
 
namespace IPS\stripecheckout;

/**
 * Stripe Checkout Gateway Application Class
 */
class _Application extends \IPS\Application
{
	
}